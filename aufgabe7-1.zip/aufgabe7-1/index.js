import express from "express";
const app = express();

const USERNAME = "zli";
const PASSWORD = "zli1234";

const basicAuth = (req, res, next) => {
    const authHeader = req.headers["authorization"];
    
    if (!authHeader || !authHeader.startsWith("Basic ")) {
        return res.status(401).json({ message: "Unauthorized" });
    }

    const base64Credentials = authHeader.split(" ")[1];
    const credentials = Buffer.from(base64Credentials, "base64").toString("utf-8");
    const [username, password] = credentials.split(":");

    if (username === USERNAME && password === PASSWORD) {
        return next();
    }

    return res.status(401).json({ message: "Invalid credentials" });
};

app.get("/public", (req, res) => {
    res.send("Erfolg");
});

app.get("/private", basicAuth, (req, res) => {
    res.send("Erfolg");
});


app.listen(3000, () => {
    console.log("It runs");
});